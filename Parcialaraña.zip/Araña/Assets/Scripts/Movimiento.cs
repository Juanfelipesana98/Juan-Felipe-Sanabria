﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movimiento : MonoBehaviour
{
    // Start is called before the first frame update
    public Transform Mitransform;
	public float speed = 1;
	void Start()
    {
        Mitransform = GetComponent<Transform>();

    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.W)){
		Mitransform.Translate(new Vector3(0,0,speed));
	 if(Input.GetKey(KeyCode.S)){
		Mitransform.Translate(new Vector3(0,0,-speed));
  if(Input.GetKey(KeyCode.A)){
		Mitransform.Translate(new Vector3(-speed,0,0));
  if(Input.GetKey(KeyCode.D)){
		Mitransform.Translate(new Vector3(speed,0,0));

		
		}
    }
}
